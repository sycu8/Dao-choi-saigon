# Xe Bay Sài Gòn — playable prototype

Single-player lightweight 3D free-roam game. Open `index.html` through a local HTTP server (`python3 -m http.server 8080`) and visit http://localhost:8080. Requires internet access to load Three.js from jsDelivr.

Features: 3 selectable stylized vehicles, all flyable; procedural buildings, stylized recognizable landmarks; animated cars and motorbikes; randomized weather (every 75 seconds); localized flooded streets with slowdown; keyboard and touch controls; multiple cameras.

Limitations: stylized procedural approximation, **not** geographically accurate OpenStreetMap geometry or licensed branded car 3D meshes. AI traffic is ambient and does not yet react to traffic lights, collisions, or jams. No live website deployment is included. Next phase: real OSM road/footprint ingestion, intersection AI, signals, water physics and optimized branded vehicle assets.

## Cloudflare Workers Static Assets deployment

This project runs as a static-assets Worker. No separate hosting, server, D1, R2, or KV needed. To deploy:

```bash
npm install
npm run check
npx wrangler login
npm run deploy
```

`npm run dev` runs Wrangler locally. `npm run build` validates and stages `public/index.html`.

**External dependency:** The prototype imports Three.js from jsDelivr. For a fully Cloudflare-served production build, vendor/bundle Three.js into `public` (rather than using an external CDN). This project currently serves the game assets on Cloudflare but still uses that external library URL.

### Fully Cloudflare-hosted build
The build now bundles Three.js into `public/game.js` using esbuild and rewrites `public/index.html` to load that local script. Run `npm ci` if a lockfile exists, or `npm install` otherwise, then `npm run check` before deploying. The root `index.html` is development source only; Cloudflare serves the compiled files under `public/`.
